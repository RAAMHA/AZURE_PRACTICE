
from sagemaker.workflow.pipeline import Pipeline
from sagemaker.workflow.steps import ProcessingStep, TrainingStep
from sagemaker.workflow.parameters import ParameterString
from sagemaker.processing import ScriptProcessor
from sagemaker.estimator import Estimator
import sagemaker

role = sagemaker.get_execution_role()

# Define parameters
input_data = ParameterString(name="InputData", default_value="s3://mlops-image-classifier-bucket/input")

# Processing step (optional for preprocessing)
# processing_step = ProcessingStep(...)

# Training step
estimator = Estimator(
    image_uri=sagemaker.image_uris.retrieve("pytorch", sagemaker.Session().boto_region_name),
    role=role,
    instance_count=1,
    instance_type="ml.m5.large",
    entry_point="train_model.py",
)

training_step = TrainingStep(
    name="TrainCNNModel",
    estimator=estimator,
    inputs={"training": input_data}
)

# Define pipeline
pipeline = Pipeline(
    name="ImageClassifierPipeline",
    parameters=[input_data],
    steps=[training_step],
)
