
import boto3

sagemaker = boto3.client('sagemaker')
response = sagemaker.create_model(
    ModelName='cnn-image-classifier',
    PrimaryContainer={
        'Image': '763104351884.dkr.ecr.us-east-1.amazonaws.com/pytorch-inference:1.12.0-cpu-py38',
        'ModelDataUrl': 's3://mlops-image-classifier-bucket/cnn_model.pth',
        'Environment': {}
    },
    ExecutionRoleArn='arn:aws:iam::<account-id>:role/sagemaker_execution_role'
)
print("Model deployed:", response)
