
# AWS MLOps: Image Classifier Project

## Overview
This project demonstrates an end-to-end MLOps pipeline on AWS for training and deploying a CNN image classifier using SageMaker and Terraform.

## Steps

1. Deploy infrastructure using `main.tf`
2. Train model using `train_model.py`
3. Upload model to S3 and deploy using `deploy_model.py`
4. Use `buildspec.yml` for CI/CD via AWS CodeBuild

## Tools Used
- AWS S3, SageMaker, IAM, CodeBuild
- Terraform
- Python, PyTorch
